import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

import os

# 设置工作目录
os.chdir(r'D:\Sueling\water_curriculum_homework\python\大一下期末')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False


# 设置配色
colors = ['#B8DBB3', '#86BC79', '#71A682', '#81989B', '#D19246', '#B5AF8B', '#7EA4B6', '#4A4F7E']

# 市场状态颜色映射
state_colors = {
    'Bull': colors[1],  # '#86BC79' 绿色系
    'Bear': colors[4],  # '#D19246' 橙色系
    'Sideways': colors[5]  # '#B5AF8B' 米色系
}
state_names = {
    'Bull': '牛市',
    'Bear': '熊市',
    'Sideways': '震荡市'
}


# 1. 读取沪深300指数数据，计算市场状态
print("读取沪深300数据")
hs300 = pd.read_csv('000300.SH.csv', encoding='gbk')
hs300 = hs300.rename(columns={'日期': 'Date', '收盘价(元)': 'Close'})
hs300['Date'] = pd.to_datetime(hs300['Date'])
hs300 = hs300.sort_values('Date').reset_index(drop=True)
hs300['MA52'] = hs300['Close'].rolling(window=52, min_periods=20).mean()
hs300_plot = hs300.dropna(subset=['MA52']).copy()


# 定义市场状态划分函数
def get_market_state(row, prev_row):
    price_above_ma = row['Close'] > row['MA52']
    ma_rising = row['MA52'] > prev_row['MA52'] if prev_row is not None else False

    if price_above_ma and ma_rising:
        return 'Bull'
    elif (not price_above_ma) and (not ma_rising) and prev_row is not None:
        return 'Bear'
    else:
        return 'Sideways'


# 计算每周的市场状态
hs300_plot['MarketState'] = 'Sideways'
for i in range(len(hs300_plot)):
    if i == 0:
        prev = None
    else:
        prev = hs300_plot.iloc[i - 1]
    hs300_plot.iloc[i, hs300_plot.columns.get_loc('MarketState')] = get_market_state(hs300_plot.iloc[i], prev)


# 2. 读取WML数据

print("读取WML数据...")
wml_24 = pd.read_csv('wml_24w.csv')
wml_24['Date'] = pd.to_datetime(wml_24['Date'])

# 3. 合并市场状态到WML数据

market_state_weekly = hs300_plot[['Date', 'MarketState']].copy()
wml_with_state = wml_24.merge(market_state_weekly, on='Date', how='left')


# 4. 计算各市场阶段下的累计收益

print("计算各阶段累计收益...")

# 全样本累计收益
wml_with_state['Cumulative_All'] = (1 + wml_with_state['WML']).cumprod()

# 分别计算各市场阶段的累计收益（在每个阶段内重新从1开始累积）
wml_with_state['Cumulative_Bull'] = np.nan
wml_with_state['Cumulative_Bear'] = np.nan
wml_with_state['Cumulative_Sideways'] = np.nan

for state in ['Bull', 'Bear', 'Sideways']:
    mask = wml_with_state['MarketState'] == state
    # 在每个阶段内重新从1开始累积
    cum = (1 + wml_with_state.loc[mask, 'WML']).cumprod()
    wml_with_state.loc[mask, f'Cumulative_{state}'] = cum

# 5. 绘制不同市场阶段下WML策略累计收益曲线

fig, ax = plt.subplots(figsize=(16, 9))

# 绘制牛市阶段的累计收益曲线（绿色）
bull_data = wml_with_state[wml_with_state['MarketState'] == 'Bull']
ax.plot(bull_data['Date'], bull_data['Cumulative_Bull'],
        color=state_colors['Bull'], linewidth=1.8, label='牛市阶段', alpha=0.9)

# 绘制熊市阶段的累计收益曲线（橙色）
bear_data = wml_with_state[wml_with_state['MarketState'] == 'Bear']
ax.plot(bear_data['Date'], bear_data['Cumulative_Bear'],
        color=state_colors['Bear'], linewidth=1.8, label='熊市阶段', alpha=0.9)

# 绘制震荡市阶段的累计收益曲线（米色）
sideways_data = wml_with_state[wml_with_state['MarketState'] == 'Sideways']
ax.plot(sideways_data['Date'], sideways_data['Cumulative_Sideways'],
        color=state_colors['Sideways'], linewidth=1.8, label='震荡市阶段', alpha=0.9)

# 添加参考线 y=1
ax.axhline(y=1, color='#4A4F7E', linestyle='--', alpha=0.5, linewidth=1.5, label='基准线')

# 设置标签和标题
ax.set_xlabel('日期', fontsize=13)
ax.set_ylabel('累计收益（倍数）', fontsize=13)
ax.set_title('不同市场阶段下WML策略累计收益曲线', fontsize=15, fontweight='bold')

# 添加网格
ax.grid(True, alpha=0.3, linestyle='--')

# 添加图例
ax.legend(loc='upper left', fontsize=11)

# 自动调整日期显示
fig.autofmt_xdate()

plt.tight_layout()
plt.savefig('不同市场阶段下WML策略累计收益曲线.png', dpi=200, bbox_inches='tight', facecolor='white')
plt.show()

print("\n不同市场阶段下WML策略累计收益曲线.png")

# 6. 打印各阶段累计收益统计

print("\n" + "=" * 60)
print("各市场阶段累计收益统计")
print("=" * 60)

for state in ['Bull', 'Bear', 'Sideways']:
    state_data = wml_with_state[wml_with_state['MarketState'] == state]
    if len(state_data) > 0:
        final_cum = state_data['Cumulative_' + state].iloc[-1]
        max_cum = state_data['Cumulative_' + state].max()
        min_cum = state_data['Cumulative_' + state].min()
        print(f"\n{state_names[state]}阶段:")
        print(f"  初始累计收益: 1.00")
        print(f"  期末累计收益: {final_cum:.4f}")
        print(f"  累计收益率: {(final_cum - 1) * 100:.2f}%")
        print(f"  最高累计收益: {max_cum:.4f}")
        print(f"  最低累计收益: {min_cum:.4f}")