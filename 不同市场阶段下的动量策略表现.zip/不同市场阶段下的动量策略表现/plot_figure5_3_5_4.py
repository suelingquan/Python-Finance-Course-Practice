import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Arc
import os

os.chdir(r'D:\Sueling\water_curriculum_homework\python\大一下期末')

plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

colors = ['#B8DBB3', '#86BC79', '#71A682', '#81989B', '#D19246', '#B5AF8B', '#7EA4B6', '#4A4F7E']

state_names = ['全样本', '牛市', '熊市', '震荡市']
state_colors = [colors[7], colors[1], colors[4], colors[5]]  # 深紫、绿、橙、米

# 绩效数据
mean_returns = [-0.5192, -0.1157, -0.8763, -0.8788]
sharpe_ratios = [-0.0244, -0.0052, -0.0424, -0.0464]
win_rates = [44.2, 51.3, 38.9, 34.1]
sample_weeks = [398, 187, 167, 44]


fig = plt.figure(figsize=(14, 12))
ax = fig.add_subplot(1, 1, 1, projection='polar')
ax.set_facecolor('#FAFAFA')

angles = np.linspace(0, 2 * np.pi, len(state_names), endpoint=False).tolist()

# 外层环形柱：平均周收益（柱高=绝对值，颜色深浅代表强度）
outer_heights = [abs(x) * 1.2 + 0.2 for x in mean_returns]
outer_bars = ax.bar(angles, outer_heights, width=0.35, color=state_colors,
                    alpha=0.9, edgecolor='white', linewidth=2)

# 内层环形柱：夏普比率（缩放15倍）
inner_heights = [abs(x) * 15 + 0.05 for x in sharpe_ratios]
inner_bars = ax.bar(angles, inner_heights, width=0.35, color=state_colors,
                    alpha=0.5, edgecolor='white', linewidth=1.5)

# 在环形柱顶部添加圆形端点
for i, (bar, val_ret, val_sharpe, win_rate, name) in enumerate(
        zip(outer_bars, mean_returns, sharpe_ratios, win_rates, state_names)):
    angle = bar.get_x() + bar.get_width() / 2
    radius = bar.get_height()

    # 平均收益标签
    ax.text(angle, radius + 0.08, f'{val_ret:.2f}%', ha='center', va='bottom',
            fontsize=11, fontweight='bold', color=state_colors[i])

    # 夏普比率标签
    inner_radius = inner_bars[i].get_height()
    ax.text(angle, inner_radius + 0.04, f'{val_sharpe:.4f}', ha='center', va='bottom',
            fontsize=8, alpha=0.8, color=state_colors[i])

    # 胜率标签
    ax.text(angle, radius + 0.16, f'胜率{win_rate:.1f}%', ha='center', va='bottom',
            fontsize=9, alpha=0.7, color='#555')

# 添加径向辅助线
for angle in angles:
    ax.plot([angle, angle], [0, 1.2], color='#E0E0E0', linewidth=0.8, alpha=0.5, zorder=0)

# 添加参考圆环
theta = np.linspace(0, 2 * np.pi, 100)
for r in [0.3, 0.6, 0.9, 1.2]:
    ax.plot(theta, [r] * len(theta), '--', color='#CCCCCC', alpha=0.3, linewidth=0.8)

# 设置标签
ax.set_xticks(angles)
ax.set_xticklabels(state_names, fontsize=13, fontweight='bold')
ax.set_ylim(0, 1.35)
ax.set_yticks([])
ax.set_title('不同市场阶段WML策略绩效对比',
             fontsize=14, fontweight='bold', pad=40)

# 添加中心圆
centre_circle = Circle((0, 0), 0.12, fc='white', ec=colors[7], linewidth=2.5, zorder=10)
ax.add_artist(centre_circle)
ax.text(0, 0, 'WML\n策略', ha='center', va='center', fontsize=10, fontweight='bold', color=colors[7])

# 添加图例
from matplotlib.patches import Patch

legend_elements = [
    Patch(facecolor=state_colors[0], alpha=0.9, label='全样本'),
    Patch(facecolor=state_colors[1], alpha=0.9, label='牛市'),
    Patch(facecolor=state_colors[2], alpha=0.9, label='熊市'),
    Patch(facecolor=state_colors[3], alpha=0.9, label='震荡市'),
]
ax.legend(handles=legend_elements, loc='upper right', bbox_to_anchor=(1.2, 1.05), fontsize=10)

plt.tight_layout()
plt.savefig('performance_chart.png', dpi=200, bbox_inches='tight', facecolor='white')
plt.show()
print("performance_chart.png")


# 赢家输家收益分解
fig2, axes = plt.subplots(1, 2, figsize=(16, 8))

# 左图：赢家和输家贡献）
ax1 = fig2.add_subplot(1, 2, 1, projection='polar')
ax1.set_facecolor('#FAFAFA')

# 赢家收益数据（正值和负值）
winner_vals = [0.10, 0.20, -0.50, -0.45]
loser_vals = [0.62, 0.32, 0.38, 0.43]

# 赢家环形柱（绿色系）
winner_heights = [abs(x) + 0.2 for x in winner_vals]
winner_bars = ax1.bar(angles, winner_heights, width=0.4, color=colors[1],
                      alpha=0.85, edgecolor='white', linewidth=2, label='赢家组合')

# 输家环形柱（橙色系，放在内层）
loser_heights = [x * 0.6 + 0.1 for x in loser_vals]  # 缩放0.6
loser_bars = ax1.bar(angles, loser_heights, width=0.4, color=colors[4],
                     alpha=0.7, edgecolor='white', linewidth=1.5, label='输家组合')

# 添加WML净收益标记（菱形）
wml_radii = [abs(x) + 0.05 for x in mean_returns]
wml_colors = [colors[4] if x < 0 else colors[1] for x in mean_returns]
ax1.scatter(angles, wml_radii, s=150, c=wml_colors, marker='D',
            edgecolor='white', linewidth=1.5, zorder=10, label='WML净收益')

# 添加数值标签
for i, (angle, w_val, l_val, wml, name) in enumerate(zip(angles, winner_vals, loser_vals, mean_returns, state_names)):
    # 赢家标签
    w_height = winner_heights[i]
    ax1.text(angle, w_height + 0.07, f'{w_val:.2f}%', ha='center', va='bottom',
             fontsize=10, fontweight='bold', color=colors[1])
    # 输家标签
    l_height = loser_heights[i]
    ax1.text(angle, l_height + 0.05, f'{l_val:.2f}%', ha='center', va='bottom',
             fontsize=9, fontweight='bold', color=colors[4])
    # WML标签
    offset = 0.08 if wml > 0 else -0.06
    ax1.text(angle, wml_radii[i] + offset, f'WML={wml:.2f}%', ha='center', va='bottom' if wml > 0 else 'top',
             fontsize=9, fontweight='bold', color=colors[7])

ax1.set_xticks(angles)
ax1.set_xticklabels(state_names, fontsize=12, fontweight='bold')
ax1.set_ylim(0, 1.2)
ax1.set_yticks([])
ax1.set_title('赢家与输家组合收益分解',
              fontsize=12, fontweight='bold', pad=25)
ax1.legend(loc='upper right', bbox_to_anchor=(1.25, 1.0), fontsize=9)

centre_circle2 = Circle((0, 0), 0.12, fc='white', ec=colors[7], linewidth=2, zorder=10)
ax1.add_artist(centre_circle2)
ax1.text(0, 0, '收益\n构成', ha='center', va='center', fontsize=8, fontweight='bold', color=colors[7])

# ----- 右图展示WML收益的净效应
ax2 = fig2.add_subplot(1, 2, 2)

# 创建x轴位置
x_pos = np.arange(len(state_names))
width = 0.7

# 堆叠条形：正负分开
positive_mask = np.array(mean_returns) >= 0
negative_mask = np.array(mean_returns) < 0

# 绘制负收益条带（向下）
neg_bars = ax2.bar(x_pos[negative_mask], np.array(mean_returns)[negative_mask], width,
                   color=colors[4], alpha=0.85, edgecolor='white', linewidth=1.5, label='负收益')

# 绘制正收益条带（向上）
pos_bars = ax2.bar(x_pos[positive_mask], np.array(mean_returns)[positive_mask], width,
                   color=colors[1], alpha=0.85, edgecolor='white', linewidth=1.5, label='正收益')

# 添加零线
ax2.axhline(y=0, color=colors[7], linestyle='-', linewidth=2, alpha=0.8)

# 添加数值标签
for i, (val, name) in enumerate(zip(mean_returns, state_names)):
    if val < 0:
        ax2.text(i, val - 0.08, f'{val:.2f}%', ha='center', va='top',
                 fontsize=11, fontweight='bold', color=colors[4])
    else:
        ax2.text(i, val + 0.08, f'{val:.2f}%', ha='center', va='bottom',
                 fontsize=11, fontweight='bold', color=colors[1])

    # 添加样本周数标注
    ax2.text(i, 0.1, f'({sample_weeks[i]}周)', ha='center', va='bottom',
             fontsize=8, alpha=0.6, color='#666')

# 设置坐标轴
ax2.set_xticks(x_pos)
ax2.set_xticklabels(state_names, fontsize=12, fontweight='bold')
ax2.set_ylabel('平均周收益 (%)', fontsize=12)
ax2.set_title('WML策略净收益分布\n', fontsize=12, fontweight='bold')
ax2.grid(True, alpha=0.3, axis='y')
ax2.set_ylim(-1.1, 0.3)
ax2.legend(loc='lower right', fontsize=9)

# 添加背景色块
ax2.axhspan(-1.1, 0, alpha=0.05, color=colors[4])
ax2.axhspan(0, 0.3, alpha=0.05, color=colors[1])

fig2.suptitle('不同市场阶段赢家与输家组合平均周收益分解', fontsize=15, fontweight='bold', y=1.02)

plt.tight_layout()
plt.savefig('decomposition_chart.png', dpi=200, bbox_inches='tight', facecolor='white')
plt.show()
print("已保存: decomposition_chart.png")