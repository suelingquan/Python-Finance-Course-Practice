import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import os

# 设置工作目录
os.chdir(r'D:\Sueling\water_curriculum_homework\python\大一下期末')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

# 设置配色
colors = ['#B8DBB3', '#86BC79', '#71A682', '#81989B', '#D19246', '#B5AF8B', '#7EA4B6', '#4A4F7E']

# 市场状态颜色映射
state_colors = {
    'Bull': colors[1],  # '#86BC79'
    'Bear': colors[4],  # '#D19246'
    'Sideways': colors[5]  # '#B5AF8B'
}
state_names = {
    'Bull': '牛市',
    'Bear': '熊市',
    'Sideways': '震荡市'
}

# 1. 读取沪深300指数数据

hs300 = pd.read_csv('000300.SH.csv', encoding='gbk')
print(f"原始数据行数: {len(hs300)}")
print(f"列名: {hs300.columns.tolist()}")

# 统一列名
hs300 = hs300.rename(columns={
    '日期': 'Date',
    '收盘价(元)': 'Close'
})

# 转换日期格式
hs300['Date'] = pd.to_datetime(hs300['Date'])

# 按日期排序
hs300 = hs300.sort_values('Date').reset_index(drop=True)

# 计算52周移动平均线
hs300['MA52'] = hs300['Close'].rolling(window=52, min_periods=20).mean()

# 剔除前52周的缺失值
hs300_plot = hs300.dropna(subset=['MA52']).copy()

print(f"绘图数据范围: {hs300_plot['Date'].min()} 至 {hs300_plot['Date'].max()}")
print(f"绘图数据行数: {len(hs300_plot)}")

# 2. 定义市场状态划分函数
def get_market_state(row, prev_row):
    price_above_ma = row['Close'] > row['MA52']
    ma_rising = row['MA52'] > prev_row['MA52'] if prev_row is not None else False

    if price_above_ma and ma_rising:
        return 'Bull'
    elif (not price_above_ma) and (not ma_rising) and prev_row is not None:
        return 'Bear'
    else:
        return 'Sideways'

# 计算每周的市场状态
hs300_plot['MarketState'] = 'Sideways'
for i in range(len(hs300_plot)):
    if i == 0:
        prev = None
    else:
        prev = hs300_plot.iloc[i - 1]
    hs300_plot.iloc[i, hs300_plot.columns.get_loc('MarketState')] = get_market_state(hs300_plot.iloc[i], prev)

# 统计各状态数量
print(f"\n市场状态统计:")
print(f"  牛市: {(hs300_plot['MarketState'] == 'Bull').sum()} 周")
print(f"  熊市: {(hs300_plot['MarketState'] == 'Bear').sum()} 周")
print(f"  震荡市: {(hs300_plot['MarketState'] == 'Sideways').sum()} 周")

# 3. 沪深300指数走势与市场状态划分

fig, ax = plt.subplots(figsize=(16, 9))

# 绘制收盘价曲线（#7EA4B6）
ax.plot(hs300_plot['Date'], hs300_plot['Close'],
        color=colors[6], linewidth=1.5, label='沪深300收盘价', alpha=0.9)

# 绘制52周移动平均线（#4A4F7E ）
ax.plot(hs300_plot['Date'], hs300_plot['MA52'],
        color=colors[7], linewidth=2, label='52周移动平均线', linestyle='--', alpha=0.8)

# 用不同颜色背景标注市场状态
states = hs300_plot['MarketState'].values
dates = hs300_plot['Date'].values

# 绘制背景色块
start_idx = 0
current_state = states[0]
for i in range(1, len(states)):
    if states[i] != current_state:
        ax.axvspan(dates[start_idx], dates[i - 1],
                   alpha=0.25, color=state_colors[current_state], zorder=0)
        start_idx = i
        current_state = states[i]
# 最后一个区间
ax.axvspan(dates[start_idx], dates[-1],
           alpha=0.25, color=state_colors[current_state], zorder=0)

# 添加图例
legend_elements = [
    Patch(facecolor=state_colors['Bull'], alpha=0.5, label='牛市'),
    Patch(facecolor=state_colors['Bear'], alpha=0.5, label='熊市'),
    Patch(facecolor=state_colors['Sideways'], alpha=0.5, label='震荡市'),
    plt.Line2D([0], [0], color=colors[6], linewidth=1.5, label='沪深300收盘价'),
    plt.Line2D([0], [0], color=colors[7], linewidth=2, linestyle='--', label='52周移动平均线')
]
ax.legend(handles=legend_elements, loc='upper left', fontsize=11)

# 设置标签和标题
ax.set_xlabel('日期', fontsize=13)
ax.set_ylabel('指数点位', fontsize=13)
ax.set_title('沪深300指数走势与市场状态划分', fontsize=15, fontweight='bold')

# 添加网格
ax.grid(True, alpha=0.3, linestyle='--')

# 设置y轴格式
ax.ticklabel_format(axis='y', style='plain', useOffset=False)

# 自动调整日期显示
fig.autofmt_xdate()

plt.tight_layout()
plt.savefig('沪深300指数走势与市场状态划分.png', dpi=200, bbox_inches='tight', facecolor='white')
plt.show()
print("\n沪深300指数走势与市场状态划分.png")


# 4. 计算各市场阶段下24周WML策略的绩效

print("不同市场阶段下24周WML策略绩效统计")
print("=" * 60)

# 读取WML数据
wml_24 = pd.read_csv('wml_24w.csv')
wml_24['Date'] = pd.to_datetime(wml_24['Date'])

# 将市场状态合并到WML数据中
market_state_weekly = hs300_plot[['Date', 'MarketState']].copy()
wml_with_state = wml_24.merge(market_state_weekly, on='Date', how='left')

from scipy import stats

# 存储结果用于表格
results = []

# 全样本
full_mean = wml_24['WML'].mean() * 100
full_std = wml_24['WML'].std() * np.sqrt(52) * 100
full_sharpe = full_mean / (full_std + 1e-6)
full_win_rate = (wml_24['WML'] > 0).mean() * 100
full_t, full_p = stats.ttest_1samp(wml_24['WML'], 0)
results.append(['全样本', len(wml_24), full_mean, full_std, full_sharpe, full_win_rate, full_t, full_p])

for state in ['Bull', 'Bear', 'Sideways']:
    state_data = wml_with_state[wml_with_state['MarketState'] == state]
    if len(state_data) > 0:
        mean_return = state_data['WML'].mean() * 100
        std_return = state_data['WML'].std() * np.sqrt(52) * 100
        sharpe = mean_return / (std_return + 1e-6)
        win_rate = (state_data['WML'] > 0).mean() * 100
        t_stat, p_value = stats.ttest_1samp(state_data['WML'], 0)
        results.append(
            [state_names[state], len(state_data), mean_return, std_return, sharpe, win_rate, t_stat, p_value])

        print(f"\n{state_names[state]}阶段:")
        print(f"  样本周数: {len(state_data)}")
        print(f"  平均周收益: {mean_return:.4f}%")
        print(f"  年化波动率: {std_return:.2f}%")
        print(f"  夏普比率: {sharpe:.4f}")
        print(f"  胜率: {win_rate:.1f}%")
        print(f"  t统计量: {t_stat:.3f}, p值: {p_value:.4f}")

# 打印表格格式
print("\n" + "=" * 60)
print("不同市场阶段下24周WML策略绩效统计表")
print("=" * 60)
print(
    f"{'市场阶段':<8} {'样本周数':<8} {'平均周收益(%)':<14} {'年化波动率(%)':<14} {'夏普比率':<10} {'胜率(%)':<8} {'t统计量':<10} {'p值':<10}")
print("-" * 90)
for r in results:
    print(f"{r[0]:<8} {r[1]:<8} {r[2]:<14.4f} {r[3]:<14.2f} {r[4]:<10.4f} {r[5]:<8.1f} {r[6]:<10.3f} {r[7]:<10.4f}")