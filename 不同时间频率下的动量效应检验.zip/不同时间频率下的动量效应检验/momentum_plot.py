import pandas as pd
import matplotlib.pyplot as plt
import os

# 设置工作目录
os.chdir(r'D:\Sueling\water_curriculum_homework\python\大一下期末')

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

# 1. 读取WML数据

wml_data = {}
for K in [4, 8, 12, 24, 48]:
    df = pd.read_csv(f'wml_{K}w.csv')
    df['Date'] = pd.to_datetime(df['Date'])
    wml_data[K] = df

# 2. 图1：累计收益曲线

plt.figure(figsize=(12, 6))
for K in [4, 8, 12, 24, 48]:
    cumulative = (1 + wml_data[K]['WML']).cumprod()
    plt.plot(wml_data[K]['Date'], cumulative, label=f'{K}周形成期', linewidth=1.5)

plt.xlabel('日期', fontsize=12)
plt.ylabel('累计收益', fontsize=12)
plt.title('不同形成期动量策略累计收益曲线', fontsize=14)
plt.legend(loc='upper left')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('不同形成期动量策略累计收益曲线.png', dpi=150)
plt.show()
print("不同形成期动量策略累计收益曲线.png")

# ============================================================
# 3. 图2：平均周收益柱状图
# ============================================================
summary = []
for K in [4, 8, 12, 24, 48]:
    mean_wml = wml_data[K]['WML'].mean() * 100
    summary.append({'K(周)': K, '平均周收益(%)': mean_wml})

summary_df = pd.DataFrame(summary)

plt.figure(figsize=(10, 6))
colors = ['red' if x < 0 else 'green' for x in summary_df['平均周收益(%)']]
plt.bar(summary_df['K(周)'].astype(str), summary_df['平均周收益(%)'], color=colors)
plt.axhline(y=0, color='black', linestyle='-', linewidth=0.8)
plt.xlabel('形成期长度(周)', fontsize=12)
plt.ylabel('平均周收益(%)', fontsize=12)
plt.title('不同形成期动量策略平均周收益', fontsize=14)
for i, v in enumerate(summary_df['平均周收益(%)']):
    plt.text(i, v + 0.02 * (1 if v > 0 else -1), f'{v:.2f}%', ha='center', fontsize=10)
plt.grid(True, alpha=0.3, axis='y')
plt.tight_layout()
plt.savefig('f不同形成期动量策略平均周收益.png', dpi=150)
plt.show()
print("不同形成期动量策略平均周收益.png")

# ============================================================
# 4. 图3：赢家 vs 输家收益对比
# ============================================================
plt.figure(figsize=(12, 6))
for K in [12, 24]:  # 选两个代表性周期
    winner_mean = wml_data[K]['Winner_Return'].mean() * 100
    loser_mean = wml_data[K]['Loser_Return'].mean() * 100
    plt.bar([f'{K}周-赢家', f'{K}周-输家'], [winner_mean, loser_mean],
            color=['green', 'red'], alpha=0.7)

plt.axhline(y=0, color='black', linestyle='-', linewidth=0.8)
plt.ylabel('平均周收益(%)', fontsize=12)
plt.title('赢家组合 vs 输家组合收益对比', fontsize=14)
plt.grid(True, alpha=0.3, axis='y')
plt.tight_layout()
plt.savefig('赢家组合 vs 输家组合收益对比.png', dpi=150)
plt.show()
print("赢家组合 vs 输家组合收益对比.png")

# 5. 图4：收益分布直方图

fig, axes = plt.subplots(2, 3, figsize=(15, 10))
axes = axes.flatten()

for idx, K in enumerate([4, 8, 12, 24, 48]):
    ax = axes[idx]
    ax.hist(wml_data[K]['WML'] * 100, bins=50, color='steelblue', edgecolor='black', alpha=0.7)
    ax.axvline(x=0, color='red', linestyle='--', linewidth=1.5)
    ax.axvline(x=wml_data[K]['WML'].mean() * 100, color='darkred', linestyle='-', linewidth=1.5)
    ax.set_xlabel('周收益(%)', fontsize=10)
    ax.set_ylabel('频数', fontsize=10)
    ax.set_title(f'{K}周形成期', fontsize=12)
    ax.text(0.95, 0.95, f'均值: {wml_data[K]["WML"].mean()*100:.2f}%',
            transform=ax.transAxes, ha='right', va='top', fontsize=9)
    ax.grid(True, alpha=0.3)

axes[5].axis('off')
plt.suptitle('WML策略周收益分布直方图', fontsize=14)
plt.tight_layout()
plt.savefig('WML策略周收益分布直方图.png', dpi=150)
plt.show()
print("WML策略周收益分布直方图.png")
