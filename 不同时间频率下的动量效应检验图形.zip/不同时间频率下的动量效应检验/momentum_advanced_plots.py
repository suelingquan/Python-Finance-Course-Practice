import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from scipy import stats
from scipy.stats import pearsonr

# 设置工作目录
os.chdir(r'D:\Sueling\water_curriculum_homework\python\大一下期末')

# 设置字体
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['axes.unicode_minus'] = False

# ============================================================
# 设置配色（7种颜色）
# ============================================================
colors = ['#B8DBB3', '#86BC79', '#71A682', '#81989B', '#D19246', '#B5AF8B', '#7EA4B6', '#4A4F7E']

sns.set_style("whitegrid")
sns.set_palette(colors)

# ============================================================
# 1. 读取WML数据
# ============================================================
wml_data = {}
for K in [4, 8, 12, 24, 48]:
    df = pd.read_csv(f'wml_{K}w.csv')
    df['Date'] = pd.to_datetime(df['Date'])
    wml_data[K] = df

# ============================================================
# 计算相关系数矩阵（单独计算，避免错误）
# ============================================================
K_list = [4, 8, 12, 24, 48]
n = len(K_list)
corr_matrix = np.zeros((n, n))

for i in range(n):
    for j in range(n):
        K1, K2 = K_list[i], K_list[j]
        # 合并两个周期的数据
        merged = pd.merge(wml_data[K1][['Date', 'WML']],
                          wml_data[K2][['Date', 'WML']],
                          on='Date', suffixes=(f'_{K1}', f'_{K2}'))
        # 计算相关系数（只取第一个返回值）
        corr_val, _ = pearsonr(merged.iloc[:, 1], merged.iloc[:, 2])
        corr_matrix[i, j] = corr_val

# ============================================================
# Figure 1: Radial Bar Chart
# ============================================================
fig, ax = plt.subplots(figsize=(14, 14), subplot_kw={'projection': 'polar'})
mean_returns = [wml_data[K]['WML'].mean() * 100 for K in K_list]
periods = [f'{K}W' for K in K_list]

angles = np.linspace(0, 2 * np.pi, len(periods), endpoint=False).tolist()
bars = ax.bar(angles, mean_returns, width=0.35, color=colors[:5],
              alpha=0.85, edgecolor='white', linewidth=1.5)

for bar, val, angle in zip(bars, mean_returns, angles):
    height = bar.get_height()
    offset = 0.08 if height >= 0 else -0.12
    ax.text(angle, height + offset, f'{val:.2f}%', ha='center',
            va='bottom' if height >= 0 else 'top', fontsize=11, fontweight='bold', color='#333')

ax.set_xticks(angles)
ax.set_xticklabels(periods, fontsize=13)
ax.set_ylim(-1, 0.5)
ax.set_title('Figure 1: Average Weekly Returns by Formation Period\n(Radial Bar Chart)',
             fontsize=16, fontweight='bold', pad=40)

theta = np.linspace(0, 2 * np.pi, 100)
for r in [-0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4]:
    ax.plot(theta, [r] * len(theta), '--', color='gray', alpha=0.3, linewidth=0.5)
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('Average Weekly Returns by Formation Period.png', dpi=200, bbox_inches='tight', facecolor='white')
plt.show()
print("saved: Average Weekly Returns by Formation Period.png")

# ============================================================
# Figure 2: Violin Plot + Box Plot
# ============================================================
fig, ax = plt.subplots(figsize=(16, 10))

parts = ax.violinplot([wml_data[K]['WML'] * 100 for K in K_list],
                      positions=range(5), widths=0.7, showmeans=False, showmedians=False)

for i, pc in enumerate(parts['bodies']):
    pc.set_facecolor(colors[i % len(colors)])
    pc.set_alpha(0.6)
    pc.set_edgecolor('white')

bp = ax.boxplot([wml_data[K]['WML'] * 100 for K in K_list],
                positions=range(5), widths=0.3, patch_artist=True,
                showfliers=False, boxprops=dict(linewidth=1.5),
                medianprops=dict(color='#4A4F7E', linewidth=2),
                whiskerprops=dict(linewidth=1.5),
                capprops=dict(linewidth=1.5))

for i, box in enumerate(bp['boxes']):
    box.set_facecolor(colors[i % len(colors)])
    box.set_alpha(0.7)

means = [wml_data[K]['WML'].mean() * 100 for K in K_list]
ax.scatter(range(5), means, color='#D19246', s=120, zorder=10, marker='D',
           edgecolor='white', linewidth=1.5, label='Mean')

ax.set_xticklabels([f'{K}W' for K in K_list], fontsize=13)
ax.set_ylabel('Weekly Return (%)', fontsize=13)
ax.set_title('WML Return Distribution by Formation Period\n(Violin Plot + Box Plot)',
             fontsize=15, fontweight='bold')
ax.axhline(y=0, color='#D19246', linestyle='--', alpha=0.5, linewidth=1.5)
ax.legend(loc='upper right', fontsize=11)
ax.grid(True, alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('WML Return Distribution by Formation Period.png', dpi=200, bbox_inches='tight', facecolor='white')
plt.show()
print("WML Return Distribution by Formation Period.png")

# ============================================================
# Figure 3: Circular Scatter + Heatmap
# ============================================================
fig = plt.figure(figsize=(18, 10))

ax1 = fig.add_subplot(1, 2, 1, projection='polar')
K_center = 24
data_24 = wml_data[24]['WML'] * 100
angles_scatter = np.linspace(0, 2 * np.pi, len(data_24))
colors_scatter = ['#D19246' if x < 0 else '#86BC79' for x in data_24]
ax1.scatter(angles_scatter, np.abs(data_24), c=colors_scatter,
            alpha=0.6, s=25, edgecolor='white', linewidth=0.3)
ax1.set_title('24W Period: Orange=Negative, Green=Positive', fontsize=12, pad=20)
ax1.set_ylim(0, max(np.abs(data_24)) * 1.1)
ax1.grid(True, alpha=0.3)

ax2 = fig.add_subplot(1, 2, 2)
im = ax2.imshow(corr_matrix, cmap='RdYlBu_r', vmin=-1, vmax=1, aspect='auto')
ax2.set_xticks(range(n))
ax2.set_yticks(range(n))
ax2.set_xticklabels([f'{K}W' for K in K_list], fontsize=11)
ax2.set_yticklabels([f'{K}W' for K in K_list], fontsize=11)
ax2.set_title('Correlation Heatmap', fontsize=13, fontweight='bold')

for i in range(n):
    for j in range(n):
        text_color = 'white' if abs(corr_matrix[i, j]) > 0.6 else 'black'
        ax2.text(j, i, f'{corr_matrix[i, j]:.2f}',
                 ha="center", va="center", color=text_color, fontsize=10)

plt.colorbar(im, ax=ax2, shrink=0.8, label='Correlation')
fig.suptitle('Circular Scatter Plot & Correlation Heatmap', fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('Circular Scatter Plot & Correlation Heatmap.png', dpi=200, bbox_inches='tight', facecolor='white')
plt.show()
print("Circular Scatter Plot & Correlation Heatmap.png")

# ============================================================
# Figure 4: Cumulative Returns + Annual Heatmap
# ============================================================
fig = plt.figure(figsize=(16, 12))

ax1 = fig.add_subplot(2, 1, 1)
for i, K in enumerate(K_list):
    cumulative = (1 + wml_data[K]['WML']).cumprod()
    ax1.fill_between(wml_data[K]['Date'], 1, cumulative, alpha=0.3, color=colors[i % len(colors)])
    ax1.plot(wml_data[K]['Date'], cumulative, label=f'{K}W', color=colors[i % len(colors)], linewidth=1.8)
ax1.axhline(y=1, color='#4A4F7E', linestyle='--', alpha=0.5)
ax1.set_ylabel('Cumulative Return (Multiple)', fontsize=12)
ax1.set_title('Cumulative Returns of WML Strategies', fontsize=14, fontweight='bold')
ax1.legend(loc='upper left', fontsize=11)
ax1.grid(True, alpha=0.3)

years = sorted(set(wml_data[4]['Date'].dt.year))
periods_label = ['4W', '8W', '12W', '24W', '48W']
heatmap_data = np.zeros((len(periods_label), len(years)))

for i, K in enumerate(K_list):
    df = wml_data[K].copy()
    df['Year'] = df['Date'].dt.year
    annual_returns = df.groupby('Year')['WML'].mean() * 100
    for j, year in enumerate(years):
        heatmap_data[i, j] = annual_returns.get(year, np.nan)

ax2 = fig.add_subplot(2, 1, 2)
im = ax2.imshow(heatmap_data, cmap='RdYlGn', aspect='auto', vmin=-1.5, vmax=0.5)
ax2.set_xticks(range(len(years)))
ax2.set_yticks(range(len(periods_label)))
ax2.set_xticklabels(years, fontsize=11, rotation=45)
ax2.set_yticklabels(periods_label, fontsize=11)
ax2.set_xlabel('Year', fontsize=12)
ax2.set_ylabel('Formation Period', fontsize=12)
ax2.set_title('Annual Average Returns Heatmap (%)', fontsize=14, fontweight='bold')

for i in range(len(periods_label)):
    for j in range(len(years)):
        if not np.isnan(heatmap_data[i, j]):
            text_color = 'white' if abs(heatmap_data[i, j]) > 0.8 else 'black'
            ax2.text(j, i, f'{heatmap_data[i, j]:.1f}', ha='center', va='center',
                     color=text_color, fontsize=9)

plt.colorbar(im, ax=ax2, shrink=0.8, label='Avg Weekly Return (%)')
fig.suptitle('Cumulative Returns & Annual Performance Heatmap', fontsize=16, fontweight='bold', y=0.98)
plt.tight_layout()
plt.savefig('Cumulative Returns & Annual Performance Heatmap.png', dpi=200, bbox_inches='tight', facecolor='white')
plt.show()
print("Cumulative Returns & Annual Performance Heatmap.png")

# ============================================================
# Figure 5: Radar Chart + Confidence Interval
# ============================================================
fig = plt.figure(figsize=(18, 10))

ax1 = fig.add_subplot(1, 2, 1, projection='polar')
metrics = ['Sharpe', 't-stat', 'Win Rate', 'Max DD', 'Info Ratio']

sharpe_ratios = []
t_stats = []
win_rates = []
max_drawdowns = []
info_ratios = []

for K in K_list:
    wml_series = wml_data[K]['WML']
    sharpe = wml_series.mean() / (wml_series.std() + 1e-6) * np.sqrt(52)
    t_stat, _ = stats.ttest_1samp(wml_series, 0)
    win_rate = (wml_series > 0).mean()
    max_dd = (wml_series.cumsum().min())
    info_ratio = wml_series.mean() / (wml_series.std() + 1e-6)

    sharpe_ratios.append(sharpe)
    t_stats.append(t_stat)
    win_rates.append(win_rate)
    max_drawdowns.append(-max_dd)
    info_ratios.append(info_ratio)


def normalize(x):
    return (x - np.min(x)) / (np.max(x) - np.min(x) + 1e-6)


radar_data = np.array([normalize(np.array(sharpe_ratios)),
                       normalize(np.array(t_stats)),
                       normalize(np.array(win_rates)),
                       normalize(np.array(max_drawdowns)),
                       normalize(np.array(info_ratios))])

angles_radar = np.linspace(0, 2 * np.pi, len(metrics), endpoint=False).tolist()
angles_radar += angles_radar[:1]

for i, K in enumerate(K_list):
    values = radar_data[:, i].tolist()
    values += values[:1]
    ax1.plot(angles_radar, values, 'o-', linewidth=2, color=colors[i % len(colors)], label=f'{K}W')
    ax1.fill(angles_radar, values, alpha=0.15, color=colors[i % len(colors)])

ax1.set_xticks(angles_radar[:-1])
ax1.set_xticklabels(metrics, fontsize=10)
ax1.set_title('Performance Metrics Radar Chart', fontsize=13, fontweight='bold', pad=25)
ax1.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0), fontsize=10)
ax1.grid(True, alpha=0.3)

ax2 = fig.add_subplot(1, 2, 2)
for i, K in enumerate(K_list):
    wml_series = wml_data[K]['WML'] * 100
    mean_val = wml_series.mean()
    ci_lower, ci_upper = np.percentile(wml_series, [2.5, 97.5])
    ax2.errorbar(i, mean_val, yerr=[[mean_val - ci_lower], [ci_upper - mean_val]],
                 fmt='o', color=colors[i % len(colors)], capsize=8, capthick=2,
                 markersize=12, elinewidth=2, zorder=5)
    np.random.seed(42)
    jitter = np.random.normal(0, 0.05, len(wml_series))
    ax2.scatter(i + jitter, wml_series, alpha=0.15, color=colors[i % len(colors)], s=10)

ax2.axhline(y=0, color='#D19246', linestyle='--', alpha=0.5)
ax2.set_xticks(range(5))
ax2.set_xticklabels([f'{K}W' for K in K_list], fontsize=12)
ax2.set_ylabel('Weekly Return (%)', fontsize=12)
ax2.set_title('95% Confidence Interval with Raw Data', fontsize=13, fontweight='bold')
ax2.grid(True, alpha=0.3, axis='y')

fig.suptitle('Performance Metrics Radar Chart & Confidence Interval', fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('Performance Metrics Radar Chart & Confidence Interval.png', dpi=200, bbox_inches='tight', facecolor='white')
plt.show()
print("Performance Metrics Radar Chart & Confidence Interval.png")

# ============================================================
# Figure 6: Network Graph
# ============================================================
fig, ax = plt.subplots(figsize=(12, 12))

angles_circle = np.linspace(0, 2 * np.pi, 5, endpoint=False)
periods_circle = [f'{K}W' for K in K_list]

for i in range(n):
    for j in range(i + 1, n):
        if abs(corr_matrix[i, j]) > 0.3:
            theta1, theta2 = angles_circle[i], angles_circle[j]
            x1, y1 = np.cos(theta1), np.sin(theta1)
            x2, y2 = np.cos(theta2), np.sin(theta2)
            mid_angle = (theta1 + theta2) / 2
            if abs(theta1 - theta2) > np.pi:
                mid_angle += np.pi
            radius_mid = 1.5
            xm, ym = radius_mid * np.cos(mid_angle), radius_mid * np.sin(mid_angle)

            t = np.linspace(0, 1, 100)
            x = (1 - t) ** 2 * x1 + 2 * (1 - t) * t * xm + t ** 2 * x2
            y = (1 - t) ** 2 * y1 + 2 * (1 - t) * t * ym + t ** 2 * y2
            ax.plot(x, y, color=colors[i % len(colors)], alpha=abs(corr_matrix[i, j]) * 0.8,
                    linewidth=abs(corr_matrix[i, j]) * 8)

for i, (angle, period, color) in enumerate(zip(angles_circle, periods_circle, colors[:5])):
    x, y = np.cos(angle), np.sin(angle)
    ax.scatter(x, y, s=900, color=color, edgecolor='white', linewidth=2.5, zorder=5)
    ax.text(x, y, period, ha='center', va='center', fontsize=13, fontweight='bold', color='white')

circle = plt.Circle((0, 0), 1, fill=False, edgecolor='#81989B', linestyle='--', alpha=0.5, linewidth=1.5)
ax.add_patch(circle)

ax.set_xlim(-1.8, 1.8)
ax.set_ylim(-1.8, 1.8)
ax.set_aspect('equal')
ax.axis('off')
ax.set_title('WML Strategy Correlation Network\n(Line Width = Correlation, Color = Period)',
             fontsize=14, fontweight='bold')

plt.tight_layout()
plt.savefig('WML Strategy Correlation Network.png', dpi=200, bbox_inches='tight', facecolor='white')
plt.show()
print("WML Strategy Correlation Network.png")

print("\n" + "=" * 60)
print("SUCCESS! All 6 figures have been generated.")
print("Files: Figure1~6.png")
print("=" * 60)