import os
import pandas as pd
import numpy as np
from scipy import stats

os.chdir(r'D:\Sueling\water_curriculum_homework\python\大一下期末')
print("工作目录已设置:", os.getcwd())

# 1. 读取处理好的数据

df = pd.read_csv('processed_data.csv')
df['Date'] = pd.to_datetime(df['Date'])

print(f"数据量: {len(df):,} 行")
print(f"股票数量: {df['Stkcd'].nunique()}")
print(f"日期范围: {df['Date'].min()} 至 {df['Date'].max()}")
print(f"可用字段: {df.columns.tolist()}")

# 2. 计算动量信号（过去K周累计收益，剔除最近一周）

print("\n计算动量信号...")
for K in [4, 8, 12, 24, 48]:
    df[f'Momentum_{K}w'] = df.groupby('Stkcd', group_keys=False).apply(
        lambda g: (1 + g['Return'].shift(1)).rolling(K).apply(lambda x: x.prod() - 1)
    )
    print(f"  K={K}周 动量信号计算完成")

# 3. 构建WML组合（每周分组）

print("\n构建WML组合...")

def calc_wml(df, K, date_col='Date', momentum_col='Momentum'):
    """计算每周的WML收益"""
    wml_list = []

    for date in df[date_col].unique():
        week_data = df[df[date_col] == date].copy()
        week_data = week_data.dropna(subset=[momentum_col])

        if len(week_data) < 100:
            continue

        # 按动量排序分10组
        week_data['Group'] = pd.qcut(week_data[momentum_col], 10, labels=False)

        # 赢家组（第9组）和输家组（第0组）
        winner = week_data[week_data['Group'] == 9]['Return'].mean()
        loser = week_data[week_data['Group'] == 0]['Return'].mean()

        wml_list.append({
            'Date': date,
            'WML': winner - loser,
            'Winner_Return': winner,
            'Loser_Return': loser
        })

    return pd.DataFrame(wml_list)

# 计算不同K值的WML
wml_results = {}
for K in [4, 8, 12, 24, 48]:
    wml_df = calc_wml(df, K, momentum_col=f'Momentum_{K}w')
    wml_results[K] = wml_df
    print(f"  K={K}周: {len(wml_df)} 个交易周")

# 4. 计算策略绩效指标

print("\n" + "=" * 50)
print("动量策略绩效统计")
print("=" * 50)

summary = []
for K, wml_df in wml_results.items():
    mean_wml = wml_df['WML'].mean() * 100  # 转为百分比
    std_wml = wml_df['WML'].std() * np.sqrt(52) * 100
    sharpe = mean_wml / (std_wml + 1e-6)

    # t检验
    t_stat, p_value = stats.ttest_1samp(wml_df['WML'], 0)

    summary.append({
        '形成期K(周)': K,
        '平均周收益(%)': f"{mean_wml:.4f}",
        '年化波动率(%)': f"{std_wml:.2f}",
        '夏普比率': f"{sharpe:.3f}",
        't统计量': f"{t_stat:.3f}",
        'p值': f"{p_value:.4f}"
    })

summary_df = pd.DataFrame(summary)
print(summary_df.to_string(index=False))

# 5. 保存WML序列

for K, wml_df in wml_results.items():
    wml_df.to_csv(f'wml_{K}w.csv', index=False)
    print(f"已保存: wml_{K}w.csv")

