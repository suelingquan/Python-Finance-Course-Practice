import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from statsmodels.graphics.tsaplots import plot_acf
import os
import warnings

warnings.filterwarnings('ignore')

os.chdir(r'D:\Sueling\water_curriculum_homework\python\大一下期末')

plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

colors = ['#B8DBB3', '#86BC79', '#71A682', '#81989B', '#D19246', '#B5AF8B', '#7EA4B6', '#4A4F7E']

print("=" * 60)
print("第七章：因子动量现象的探索与实证")
print("=" * 60)

# 1. 读取因子数据

print("\n1. 读取因子数据...")

# 读取三因子数据
ff = pd.read_csv('THRFACDAT_WEEKLY.csv', encoding='gbk')
ff['Date'] = pd.to_datetime(ff['Date'])
ff = ff.rename(columns={'Rmrf_tmv': 'MKT', 'Smb_tmv': 'SMB', 'Hml_tmv': 'HML'})

# 读取WML数据
wml_24 = pd.read_csv('wml_24w.csv')
wml_24['Date'] = pd.to_datetime(wml_24['Date'])

# 合并因子数据
factors = ff[['Date', 'SMB', 'HML']].copy()
factors = factors.merge(wml_24[['Date', 'WML']], on='Date', how='inner')
factors = factors.sort_values('Date').reset_index(drop=True)

print(f"  因子数据量: {len(factors)} 行")
print(f"  日期范围: {factors['Date'].min()} 至 {factors['Date'].max()}")
print(f"  因子列: {factors.columns.tolist()}")

# 2. 因子收益率描述性统计

print("\n2. 因子收益率描述性统计...")

print("\n  " + "=" * 50)
print("  各因子收益率统计")
print("  " + "=" * 50)
for factor in ['SMB', 'HML', 'WML']:
    mean_ret = factors[factor].mean() * 100
    std_ret = factors[factor].std() * 100
    sharpe = factors[factor].mean() / factors[factor].std() * np.sqrt(52)
    t_stat, p_val = stats.ttest_1samp(factors[factor], 0)
    print(f"  {factor}: 均值={mean_ret:.4f}%, 波动率={std_ret:.2f}%, 夏普={sharpe:.3f}, t={t_stat:.3f}")

# 3.因子累计收益曲线

print("\n3. 绘制因子累计收益曲线")

fig, ax = plt.subplots(figsize=(12, 6))

for i, factor in enumerate(['SMB', 'HML', 'WML']):
    cumulative = (1 + factors[factor]).cumprod()
    ax.plot(factors['Date'], cumulative, label=factor, color=colors[i], linewidth=1.5)

ax.axhline(y=1, color='gray', linestyle='--', alpha=0.5)
ax.set_xlabel('日期', fontsize=12)
ax.set_ylabel('累计收益（倍数）', fontsize=12)
ax.set_title('SMB、HML、WML因子累计收益曲线', fontsize=14, fontweight='bold')
ax.legend(loc='upper left', fontsize=11)
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('SMB、HML、WML因子累计收益曲线.png', dpi=200, bbox_inches='tight', facecolor='white')
plt.show()
print("SMB、HML、WML因子累计收益曲线.png")

# 4. 自相关分析

print("\n4. 自相关分析...")

fig, axes = plt.subplots(1, 3, figsize=(15, 5))

for i, factor in enumerate(['SMB', 'HML', 'WML']):
    ax = axes[i]
    plot_acf(factors[factor], lags=12, ax=ax, alpha=0.05, color=colors[i])
    ax.set_title(f'{factor}因子自相关图', fontsize=12, fontweight='bold')
    ax.set_xlabel('滞后阶数（周）', fontsize=10)
    ax.set_ylabel('自相关系数', fontsize=10)
    ax.grid(True, alpha=0.3)

plt.suptitle('SMB、HML、WML因子自相关系数', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('SMB、HML、WML因子自相关系数.png', dpi=200, bbox_inches='tight', facecolor='white')
plt.show()
print("SMB、HML、WML因子自相关系数.png")

# 输出自相关系数表格
print("\n  自相关系数（前4阶）:")
print("  " + "=" * 50)
print("  滞后阶数    SMB      HML      WML")
print("  " + "-" * 40)
for lag in range(1, 5):
    smb_acf = factors['SMB'].autocorr(lag=lag)
    hml_acf = factors['HML'].autocorr(lag=lag)
    wml_acf = factors['WML'].autocorr(lag=lag)
    print(f"  {lag:^8}   {smb_acf:+.3f}    {hml_acf:+.3f}    {wml_acf:+.3f}")

# 5. 因子动量预测性回归

print("\n5. 因子动量预测性回归...")

def momentum_regression(factor_series, K=12, H=4):

    factor_returns = factor_series.values
    n = len(factor_returns)

    X = []
    y = []

    for i in range(K, n - H + 1):
        past_momentum = (1 + factor_returns[i - K:i]).prod() - 1
        future_return = (1 + factor_returns[i:i + H]).prod() - 1
        X.append(past_momentum)
        y.append(future_return)

    X = np.array(X)
    y = np.array(y)

    # 简单线性回归
    from scipy import stats
    slope, intercept, r_value, p_value, std_err = stats.linregress(X, y)

    return {
        'beta': slope,
        'intercept': intercept,
        'r_squared': r_value ** 2,
        'p_value': p_value,
        't_stat': slope / std_err if std_err > 0 else 0,
        'n_obs': len(X)
    }


# 检验不同参数组合
K_values = [4, 8, 12, 24]
H_values = [4, 8, 12, 24]

print("\n  预测性回归结果（β系数）:")
print("  " + "=" * 60)
print("  因子    K(周)   H(周)      β系数      t统计量      R²       p值")
print("  " + "-" * 60)

results = []
for factor in ['SMB', 'HML', 'WML']:
    for K in K_values:
        for H in H_values:
            if K > len(factors) - H:
                continue
            res = momentum_regression(factors[factor], K=K, H=H)
            sig = '***' if res['p_value'] < 0.01 else (
                '**' if res['p_value'] < 0.05 else ('*' if res['p_value'] < 0.1 else ''))
            print(
                f"  {factor}     {K:^6}    {H:^6}    {res['beta']:+.4f}      {res['t_stat']:6.2f}{sig}    {res['r_squared']:.3f}    {res['p_value']:.4f}")
            results.append({
                'factor': factor,
                'K': K,
                'H': H,
                'beta': res['beta'],
                't_stat': res['t_stat'],
                'r_squared': res['r_squared'],
                'p_value': res['p_value']
            })

# 6. 因子动量配置策略

print("\n6. 构建因子动量配置策略...")


def factor_momentum_strategy(factors, lookback=12, rebalance_freq=4):

    factors = factors.copy()
    n = len(factors)
    weights = np.zeros((n, 3))  # SMB, HML, WML
    portfolio_returns = []

    for i in range(lookback, n):
        # 计算过去lookback周各因子的累计收益
        past_returns = []
        for j, factor in enumerate(['SMB', 'HML', 'WML']):
            cum_ret = (1 + factors[factor].iloc[i - lookback:i]).prod() - 1
            past_returns.append(cum_ret)

        # 按动量排序，动量最强的因子获得最高权重
        sorted_idx = np.argsort(past_returns)[::-1]  # 降序

        # 权重分配：最强50%，次强30%，最弱20%
        w = np.zeros(3)
        w[sorted_idx[0]] = 0.50
        w[sorted_idx[1]] = 0.30
        w[sorted_idx[2]] = 0.20

        weights[i] = w

        # 计算组合收益
        daily_ret = np.sum(w * factors[['SMB', 'HML', 'WML']].iloc[i])
        portfolio_returns.append(daily_ret)

    # 计算基准收益（等权重）
    benchmark_returns = factors[['SMB', 'HML', 'WML']].iloc[lookback:].mean(axis=1).values

    return pd.Series(portfolio_returns, index=factors.index[lookback:]), pd.Series(benchmark_returns,
                                                                                   index=factors.index[lookback:])
# 运行策略
strategy_returns, benchmark_returns = factor_momentum_strategy(factors, lookback=12, rebalance_freq=4)

# 7. 策略累计收益对比

print("\n因子动量配置策略与等权重基准累计收益对比")

fig, ax = plt.subplots(figsize=(12, 6))

strategy_cum = (1 + strategy_returns).cumprod()
benchmark_cum = (1 + benchmark_returns).cumprod()
dates = factors['Date'].iloc[len(factors) - len(strategy_cum):]

ax.plot(dates, strategy_cum, label='因子动量配置策略', color=colors[1], linewidth=2)
ax.plot(dates, benchmark_cum, label='等权重基准', color=colors[4], linewidth=1.5, linestyle='--')
ax.axhline(y=1, color='gray', linestyle='-', alpha=0.5)

ax.set_xlabel('日期', fontsize=12)
ax.set_ylabel('累计收益（倍数）', fontsize=12)
ax.set_title('因子动量配置策略与等权重基准累计收益对比', fontsize=14, fontweight='bold')
ax.legend(loc='upper left', fontsize=11)
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('因子动量配置策略与等权重基准累计收益对比.png', dpi=200, bbox_inches='tight', facecolor='white')
plt.show()
print("因子动量配置策略与等权重基准累计收益对比.png")

# 8. 绩效统计表

print("\n8. 策略绩效统计...")

print("\n  " + "=" * 60)
print("  因子动量配置策略绩效对比表")
print("  " + "=" * 60)

# 计算绩效指标
def performance_metrics(returns):
    ann_return = returns.mean() * 52 * 100
    ann_vol = returns.std() * np.sqrt(52) * 100
    sharpe = ann_return / (ann_vol + 1e-6)
    max_dd = ((1 + returns).cumprod().cummax() - (1 + returns).cumprod()).max() * 100
    win_rate = (returns > 0).mean() * 100
    return ann_return, ann_vol, sharpe, max_dd, win_rate

strategy_ann_ret, strategy_ann_vol, strategy_sharpe, strategy_max_dd, strategy_win_rate = performance_metrics(
    strategy_returns)
benchmark_ann_ret, benchmark_ann_vol, benchmark_sharpe, benchmark_max_dd, benchmark_win_rate = performance_metrics(
    benchmark_returns)

print("\n  " + "-" * 60)
print(f"  策略                 年化收益率(%)   年化波动率(%)   夏普比率   最大回撤(%)   胜率(%)")
print("  " + "-" * 60)
print(
    f"  因子动量配置策略      {strategy_ann_ret:12.2f}   {strategy_ann_vol:12.2f}   {strategy_sharpe:8.3f}   {strategy_max_dd:10.2f}   {strategy_win_rate:8.1f}")
print(
    f"  等权重基准            {benchmark_ann_ret:12.2f}   {benchmark_ann_vol:12.2f}   {benchmark_sharpe:8.3f}   {benchmark_max_dd:10.2f}   {benchmark_win_rate:8.1f}")
print("  " + "-" * 60)

# 保存结果
results_df = pd.DataFrame(results)
results_df.to_csv('因子动量配置策略绩效对比表.csv', index=False)
print("\n  回归结果已保存到 因子动量配置策略绩效对比表.csv")
