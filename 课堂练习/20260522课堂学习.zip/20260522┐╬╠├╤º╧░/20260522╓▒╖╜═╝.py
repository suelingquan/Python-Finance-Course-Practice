import numpy as np
import matplotlib.pyplot as plt
from matplotlib import style
from matplotlib.colors import LinearSegmentedColormap
#设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei'] # Windows黑体

colors_raw = [
    (246, 153, 141), (107, 165, 189), (222, 238, 237), (254, 236, 231), (255, 227, 191),
    (31, 102, 130), (107, 165, 187), (246, 153, 141), (164, 218, 204), (245, 245, 245)
]

colors = [(r/255, g/255, b/255) for r, g, b in colors_raw]
# 创建平滑渐变的colormap
cmap = LinearSegmentedColormap.from_list('custom_cmap', colors, N=256)

np.random.seed(42)
array = np.random.normal(loc=1, scale=1, size=10000)
fig, ax = plt.subplots()
# 用 counts, bins, patches 接收返回值，然后逐个上色
counts, bins, patches = ax.hist(array, bins=100, edgecolor='black', alpha=0.8)

# 为每个柱子设置渐变色（按位置渐变）
bin_centers = (bins[:-1] + bins[1:]) / 2
x_min, x_max = bins[0], bins[-1]
bin_norm = (bin_centers - x_min) / (x_max - x_min)
for patch, norm_val in zip(patches, bin_norm):
    patch.set_facecolor(cmap(norm_val))

plt.title('直方图平滑渐变')
plt.xlabel('数值')
plt.ylabel('频数')
plt.show()