import numpy as np
import matplotlib.pyplot as plt
from matplotlib import style
from matplotlib.colors import LinearSegmentedColormap
#设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei'] # Windows黑体
np.random.seed(271)
X = np.random.randn(100,7)*0.02
Y = np.corrcoef(X.T)
print(Y)

fig, ax = plt.subplots()
ax.imshow(Y)
plt.title('热力图')
plt.show()
