import numpy as np
import matplotlib.pyplot as plt
from matplotlib import style
from matplotlib.colors import LinearSegmentedColormap
#设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei'] # Windows黑体

colors_raw = [
    (246, 153, 141), (107, 165, 189), (222, 238, 237), (254, 236, 231), (255, 227, 191),
    (31, 102, 130), (107, 165, 187), (246, 153, 141), (164, 218, 204), (245, 245, 245)
]

colors = [(r/255, g/255, b/255) for r, g, b in colors_raw]

# 创建平滑渐变的colormap
cmap = LinearSegmentedColormap.from_list('custom_cmap', colors, N=256)

np.random.seed(42)
Finance = np.random.normal(loc=1, scale=1, size=10000)
Tech= np.random.normal(loc=0.1, scale=0.5, size=10000)
Retail = np.random.normal(loc=0.5, scale=0.1, size=10000)

data = [Finance,Tech,Retail]
labels = ['Finance', 'Technology', 'Retail']

fig, ax = plt.subplots()
ax.boxplot(data,tick_labels=labels,vert=False,patch_artist=True)

plt.title('箱线图')
plt.show()